# Current Status

Last updated: 2026-07-31

## Product

ArmProof is the approved working concept: CI for Arm AI optimization pull
requests. Earlier product directions are historical only and must not influence
implementation.

## Phase

Evidence core complete; reference service and capacity harness validation in
progress. Polished report and CI product work remain gated by `CAP-001`.

## Established Technical Evidence

On AWS Graviton4 `c8g.4xlarge`, the existing result-first experiments showed:

- INT4 artifact size reduction: 35.92% versus BF16.
- Peak PSS reduction: 55.34% versus BF16.
- Time-weighted PSS reduction: 59.66% versus BF16.
- KleidiAI enabled/disabled speedup: 1.72x to 2.59x with the identical INT4
  model and runtime.
- Quality: 20/24 INT4 versus 19/24 BF16; both 24/24 parseable.
- `kai_*` callchains present in enabled evidence and absent when disabled.

The original loaded-RSS experiment remains a recorded no-go under its frozen
metric. A separately preregistered runtime-PSS follow-up passed all nine gates.

## Unresolved Grand-Prize Gate

Prove that the matched KleidiAI treatment produces at least 1.5x sustainable
throughput at the same p95 SLO in two of three traffic mixes. The preferred
headline target is 1.7x. This is serving validation of an established
mechanism, not another optimization search.

## Immediate Next Action

Complete `AWS-001`, run the real `SERVICE-001` Graviton smoke, and execute the
fixed-SLO load harness prerequisites. Do not begin report polish before
`CAP-001` passes.

## Verified Commands

```bash
make check
PYTHONPATH=src python3.12 -m armproof.cli verify \
  --contract examples/fixture-pass/contract.json \
  --comparison examples/fixture-pass/comparison.json
```

## Known Constraints

- Large source archives and runtime binaries remain external but are hashed in
  the imported manifest; 51 reviewable evidence files are stored locally.
- The repository has no configured remote.
- Project source is Apache-2.0; BANKING77 is separately attributed CC-BY-4.0.
- AWS work has standing approval within the all-in USD 15 ceiling; cumulative
  spend must include the approximately USD 1.43 feasibility sessions.
- The real localhost service integration cannot run in the current agent
  network sandbox; it remains mandatory on Graviton.
