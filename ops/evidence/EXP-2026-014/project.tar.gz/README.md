# SurgeDesk + ArmProof

SurgeDesk is a human-confirmed banking-support application running Phi-4 Mini
INT4 on AWS Graviton4. ArmProof is the reusable release gate that connects its
Arm optimization evidence to the deployment.

The live product starts on a KleidiAI-disabled control lane. A platform operator
recomputes the preregistered capacity and Arm-execution evidence, activates the
matching treatment, and routes the next support request through the
KleidiAI-enabled lane. The reviewed-ticket table records which deployment served
each real request.

**Challenge track:** Cloud AI, Arm Create AI Optimization Challenge.

## Measured Result

On the same CPU-only AWS `c8g.4xlarge`, with the same Phi-4 Mini INT4 model,
ONNX Runtime GenAI build, 16 threads, workload and ten-second p95 service
objective:

| Preregistered confirmation | Rate | Five 500-second windows |
|---|---:|---:|
| KleidiAI disabled control | 0.28 requests/s | 5 failed |
| KleidiAI enabled treatment | 0.56 requests/s | 5 passed |

Discovery first located the standard service between 0.24 and 0.28 requests/s
and found the optimized service passing at 0.56; the next 0.60 probe was mixed.
The final contract therefore froze only the one-sided standard failure at 0.28
and optimized pass at 0.56. It did not use 0.60 as an exact boundary.

The public capacity claim for the frozen mixed banking-support workload is the conservative lower bound
`0.56 / 0.28 = at least 2.0x` sustained request rate. The final contract was
committed before the confirmation instance was created; any control pass,
treatment failure, missing request row, quality breach or identity mismatch
rejects the release.

The release verifier measures every capacity request from its scheduled send
time through completion, including client dispatch delay. A response completing
after the 500-second window plus the ten-second SLO drain fails that request.
Each raw response must also repeat the expected source-model, runtime, Arm64,
thread and KleidiAI identity.

The release also verifies:

- 2,100 raw request outcomes from the ten capacity windows;
- 1,540 raw model outputs, 770 from each lane;
- less than one percentage point of accuracy and macro-F1 loss;
- at least 99% valid output schema;
- zero `kai_*` function samples in the Arm Performix control;
- at least 50% `kai_*` function-sample share in the treatment; and
- at least 100,000 Performix function samples per treatment.

Supporting optimization results include 1.72x to 2.59x faster direct inference
across four input shapes. The earlier BF16-to-INT4 migration measured 35.92%
smaller model files, 55.34% lower peak proportional set size (PSS) and 59.66%
lower time-weighted PSS. Quantization results and KleidiAI results
remain separate causal comparisons.

## Product Workflow

```text
real support message
        |
        v
Phi-4 intent -> SurgeDesk procedure + queue guard -> human chooses final queue
        |
        v
control lane recorded in the ticket audit trail
        |
        v
verify preregistered capacity + raw quality + native Performix evidence
        |
        v
match live source model, runtime, Arm64 shape, threads and treatment controls
        |
        v
activate KleidiAI treatment -> next real request records optimized lane + audit ID
```

The five-queue routing guard was built on 2,310 BANKING77 examples and evaluated
on a disjoint 770-message development holdout. It raised routing accuracy from
74.42% for direct model mapping to 86.75%. A person still selects every final
queue, and this routing feature is separate from the Arm performance result.

## Verify The Reference

Prerequisite: Python 3.12.

```bash
git clone https://github.com/QasimKhan5x/ArmProof.git
cd ArmProof
python3.12 -m venv .venv
.venv/bin/python -m pip install -e .
.venv/bin/armproof ci examples/armproof-reference/armproof.json
```

The command verifies the archive ledgers, re-derives end-to-end capacity and quality from
raw rows, parses native Arm Performix exports, binds the observed treatment
identities to `confirmed-contract.json`, and writes:

- `decision.json`
- `comparison.json`
- `summary.json`
- `verification.json`
- an offline HTML report

Exit `0` approves every required claim. Exit `2` means at least one required
claim failed or remained unknown. Exit `1` means the evidence or configuration
was invalid.

## Run The Product

```bash
python3.12 scripts/build_surgedesk_demo.py --verify
python3.12 scripts/serve_surgedesk.py --port 8765
```

Open <http://127.0.0.1:8765/surgedesk/>. This local path uses the checked-in
evidence and recorded BANKING77 examples, so judges can inspect the workflow
without AWS credentials or model downloads.

The three views have stable URLs:

- `#triage`: support workflow and human routing decision
- `#surge`: preregistered capacity audit and raw outcomes
- `#proof`: activation control, optimization summary and Arm Performix evidence

The full recording uses real Graviton inference before and after activation.
The exact commands and expected outputs are in
[`submission/DEMO_SCRIPT.md`](submission/DEMO_SCRIPT.md).

## Reuse ArmProof

ArmProof provides:

- versioned performance, quality and Arm-execution contracts;
- a fixed-rate HTTP load generator;
- hash-locked raw request and raw model-output verification;
- native Arm Performix Code Hotspots parsing;
- model, runtime, workload and environment identity binding;
- an offline report and machine-readable receipt;
- a GitHub Action for pull-request release gates;
- a blocked-by-default starter generated by `armproof init`; and
- a public evidence-adapter interface for other runtimes.

Generate a starter for another bounded HTTP classification service:

```bash
.venv/bin/armproof init \
  --endpoint http://127.0.0.1:8000/infer \
  --output my-arm-service
cd my-arm-service
../.venv/bin/armproof ci armproof.json
```

The initial check fails until the developer collects real request rows,
profiler output, observed identities and a checksum ledger. The executable
reference shape is in [`examples/http-slo/`](examples/http-slo/). The tested
[`examples/llama-cpp-http-slo/`](examples/llama-cpp-http-slo/) adapter confirms
endpoint compatibility; it does not claim a llama.cpp performance result.

Use ArmProof in GitHub Actions:

```yaml
- uses: QasimKhan5x/ArmProof@main
  with:
    config: armproof.json
    contract-sha256: REPLACE_WITH_THE_PROTECTED_CONTRACT_DIGEST
```

Protect the workflow and contract with `CODEOWNERS` and branch rules. The
Action checks the contract digest before reading evidence.

## Arm Optimization Details

- **Hardware:** AWS Graviton4, `c8g.4xlarge`, 16 Arm Neoverse V2 cores
- **Model:** `microsoft/Phi-4-mini-instruct-onnx`, pinned revision, CPU INT4
- **Runtime:** pinned ONNX Runtime and ONNX Runtime GenAI Arm64 builds
- **Arm library:** KleidiAI v1.20 through ONNX Runtime
- **Control:** `mlas.disable_kleidiai=1`
- **Treatment:** `mlas.disable_kleidiai=0`
- **Profiler:** Arm Performix 1.20 Code Hotspots, with Linux perf as a separate cycle view
- **Workload:** frozen BANKING77 quality and mixed traffic inputs
- **SLO:** p95 at or below 10 seconds, zero errors, at least 95% delivery

The Performix release gate uses function samples in their native units. Linux
perf cycle attribution is supporting evidence and is not numerically compared
with the Performix percentage.

## Test The Project

```bash
make check
npm ci
npx playwright install chromium
npm run test:logic
npm run test:ui
```

Tests cover policy evaluation, archive derivation, raw-output quality checks,
native Performix parsing, gateway identity binding, a real localhost control to
treatment HTTP flow, the SurgeDesk workflow, the offline report and responsive
layouts down to 320 pixels.

## Repository Map

- [`submission/DEVPOST_SUBMISSION.md`](submission/DEVPOST_SUBMISSION.md): copy-ready submission
- [`submission/DEMO_SCRIPT.md`](submission/DEMO_SCRIPT.md): setup and three-minute recording sequence
- [`submission/JUDGE_GUIDE.md`](submission/JUDGE_GUIDE.md): fastest evaluation path
- [`submission/TECHNICAL_EVIDENCE.md`](submission/TECHNICAL_EVIDENCE.md): claim-to-artifact map
- [`examples/armproof-reference/`](examples/armproof-reference/): release contract and config
- [`ops/experiments/`](ops/experiments/): preregistered experiments
- [`ops/evidence/`](ops/evidence/): accepted and rejected evidence history
- [`examples/phi4-graviton/`](examples/phi4-graviton/): pinned Arm deployment
- [`docs/PERFORMIX.md`](docs/PERFORMIX.md): native Performix collection and interpretation

## Scope And Provenance

ArmProof verifies a declared contract for a pinned model, workload, runtime and
machine. Repository SHA-256 ledgers detect changes after collection; they are
integrity controls rather than independent attestation of the original AWS
host. The live gateway rechecks content-derived source-model and runtime
identities, while AWS hardware provenance comes from the recorded environment
and profiler exports.

The project is MIT licensed. BANKING77 is used under CC BY 4.0 and credited in
[`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md). Model weights are downloaded
from their original source and are not redistributed.
