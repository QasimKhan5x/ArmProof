#!/usr/bin/env python3
"""Refresh starter identities after replacing placeholders and before collection."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


workload_manifest = ROOT / "identity-sources/workload-manifest.json"
write(workload_manifest, {
    "capacity_workload_sha256": sha256(ROOT / "workload.jsonl"),
    "quality_workload_sha256": sha256(ROOT / "quality.jsonl"),
})
common = {
    "artifact_sha256": sha256(ROOT / "identity-sources/artifact.ref"),
    "runtime_sha256": sha256(ROOT / "identity-sources/runtime.lock"),
    "workload_sha256": sha256(workload_manifest),
    "environment_sha256": sha256(ROOT / "identity-sources/environment.json"),
}
contract_path = ROOT / "contract.json"
contract = load(contract_path)
for treatment in contract["treatments"]:
    treatment.update(common)
write(contract_path, contract)

evidence_root = ROOT / "evidence"
(evidence_root / "identity-sources").mkdir(parents=True, exist_ok=True)
(evidence_root / "profiles").mkdir(parents=True, exist_ok=True)
(evidence_root / "quality").mkdir(parents=True, exist_ok=True)
(evidence_root / "requests").mkdir(parents=True, exist_ok=True)
for source, destination in (
    ("templates/protocol.json", "evidence/protocol.json"),
    ("templates/identities.json", "evidence/identities.json"),
    ("identity-sources/artifact.ref", "evidence/identity-sources/artifact.ref"),
    ("identity-sources/runtime.lock", "evidence/identity-sources/runtime.lock"),
    ("identity-sources/environment.json", "evidence/identity-sources/environment.json"),
    ("identity-sources/workload-manifest.json", "evidence/identity-sources/workload-manifest.json"),
    ("workload.jsonl", "evidence/identity-sources/capacity.jsonl"),
    ("quality.jsonl", "evidence/identity-sources/quality.jsonl"),
):
    shutil.copyfile(ROOT / source, ROOT / destination)

profile_path = ROOT / "templates/profile-manifest.json"
profile = load(profile_path)
treatments = {row["id"]: row for row in contract["treatments"]}
for run in profile["runs"].values():
    treatment = treatments[run["treatment_id"]]
    run.update(common)
    command = json.dumps(treatment["command"], separators=(",", ":")).encode("utf-8")
    run["command_sha256"] = hashlib.sha256(command).hexdigest()
    report = evidence_root / run["report"]
    if report.is_file():
        run["report_sha256"] = sha256(report)
write(profile_path, profile)
write(evidence_root / "profiles/manifest.json", profile)

workflow_path = ROOT / ".github/workflows/armproof.yml"
workflow = workflow_path.read_text(encoding="utf-8")
workflow = re.sub(
    r"contract-sha256: [0-9a-f]{64}",
    f"contract-sha256: {sha256(contract_path)}",
    workflow,
)
workflow_path.write_text(workflow, encoding="utf-8")
print("Refreshed evidence layout, identities, commands, contract, and workflow digests.")
