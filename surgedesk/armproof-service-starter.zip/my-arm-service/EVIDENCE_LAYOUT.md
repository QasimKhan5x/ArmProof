# Evidence Layout

`collection-plan.json` contains these paths as machine-readable JSON. Collect each file from matched baseline and treatment runs; never reuse one confirmation under more than one name.

```text
evidence/
  protocol.json
  identities.json
  baseline.perf
  treatment.perf
  profiles/manifest.json
  quality/baseline-samples.jsonl
  quality/treatment-samples.jsonl
  requests/{baseline,treatment}-{pass,fail}-{1,2,3}.jsonl
  identity-sources/artifact.ref
  identity-sources/runtime.lock
  identity-sources/environment.json
  identity-sources/workload-manifest.json
  identity-sources/capacity.jsonl
  identity-sources/quality.jsonl
```

Edit the workload, identity sources, service commands, protocol rates, and claim limits first. `python3 refresh_bindings.py` creates the evidence directories, copies the templates and source files, and recalculates every embedded digest.

Collect each lane and boundary three times with `armproof capacity`. For each run, copy its `requests-rps-<rate>.jsonl` file to the corresponding `evidence/requests/<lane>-<pass-or-fail>-<1-3>.jsonl` path shown above. Run `armproof quality` once against each lane and copy each `quality-samples.jsonl` to `evidence/quality/<lane>-samples.jsonl`. Capture each service under representative load with `perf record -e cycles:P -g -p <pid> -- sleep 60`, then render parser-ready reports with `perf report --stdio` into `evidence/baseline.perf` and `evidence/treatment.perf`. Rerun `python3 refresh_bindings.py` to hash those reports, then run:

```bash
armproof seal armproof.json
armproof ci armproof.json
```

The exact flags are listed by `armproof capacity --help` and `armproof quality --help`; the generated `collection-plan.json` is the machine-readable checklist. A complete passing parser example is executable under `examples/http-slo/` in the ArmProof repository and is explicitly labeled synthetic.
