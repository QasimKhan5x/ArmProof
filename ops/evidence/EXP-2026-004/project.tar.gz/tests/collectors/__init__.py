"""Collector tests."""
