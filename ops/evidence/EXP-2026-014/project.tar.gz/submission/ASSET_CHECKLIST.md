# Devpost Media Assets

Upload these in order after they are copied into `submission/assets/`:

1. `01-surge-capacity.png` - use as the cover image. It communicates the
   at-least-2x sustained result, complete trial matrix and fixed-SLO comparison.
2. `02-triage-guard.png` - shows the real application and the queue guard
   correcting an LLM route.
3. `03-release-proof.png` - shows the core Arm Performix experiment, sustained
   claim ledger and Arm
   optimization path.
4. `04-mobile-proof.png` - optional; demonstrates responsive product quality.

Suggested captions:

- **Same Graviton4 instance, at least 2x sustainable mixed traffic.** Ten
  preregistered 500-second windows show five control failures at 0.28 requests/s
  and five treatment passes at 0.56 requests/s.
- **A real support workflow.** The two-stage route
  reaches 86.75% held-out operational queue accuracy and remains
  human-confirmed.
- **The release decision comes from ArmProof.** The audit derives 2,100 capacity
  requests and 1,540 original model outputs, binds both treatments, and
  evaluates ten required claims before activation becomes available.
- **Judgeable on any screen.** SurgeDesk and the offline evidence report are
  tested down to 320 pixels.

Do not upload raw profiler text as a primary image. It is available through
the repository and evidence links for technical inspection.
