"""Re-derive supporting EXP-2026-002 optimization measurements."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"supporting evidence is not an object: {path.name}")
    return value


def _reduction(reference: float, treatment: float) -> float:
    if reference <= 0 or treatment <= 0:
        raise ValueError("supporting size and memory values must be positive")
    return (1 - treatment / reference) * 100


def derive_supporting_optimization(root: Path, lock_path: Path) -> dict[str, Any]:
    lock = _json(lock_path)
    expected = lock.get("files")
    required = {"bf16.json", "ort-disabled.json", "ort-enabled.json", "summary.json"}
    if (
        lock.get("schema_version") != "1.0.0"
        or lock.get("experiment_id") != "EXP-2026-002"
        or not isinstance(expected, dict)
        or set(expected) != required
    ):
        raise ValueError("supporting evidence lock is invalid")
    for name, digest in expected.items():
        path = root / name
        if not path.is_file() or _sha256(path) != digest:
            raise ValueError(f"supporting evidence digest mismatch: {name}")

    bf16 = _json(root / "bf16.json")
    disabled = _json(root / "ort-disabled.json")
    enabled = _json(root / "ort-enabled.json")
    stored = _json(root / "summary.json").get("summary")
    if not isinstance(stored, dict):
        raise ValueError("supporting summary is invalid")
    disabled_shapes = disabled.get("performance")
    enabled_shapes = enabled.get("performance")
    if (
        not isinstance(disabled_shapes, list)
        or not isinstance(enabled_shapes, list)
        or len(disabled_shapes) != 4
        or len(enabled_shapes) != 4
    ):
        raise ValueError("supporting direct-inference matrix must contain four shapes")

    gains: list[float] = []
    shapes: list[dict[str, Any]] = []
    for control, treatment in zip(disabled_shapes, enabled_shapes, strict=True):
        identity = (control.get("batch"), control.get("prompt_length"))
        if identity != (treatment.get("batch"), treatment.get("prompt_length")):
            raise ValueError("supporting direct-inference shapes are not matched")
        gain = float(control["median"]["end_to_end_seconds"]) / float(
            treatment["median"]["end_to_end_seconds"]
        )
        gains.append(gain)
        shapes.append({"batch": identity[0], "prompt_length": identity[1], "speedup": gain})

    result = {
        "experiment_id": "EXP-2026-002",
        "disk_reduction_percent": _reduction(
            float(bf16["model_bytes"]), float(enabled["model_bytes"])
        ),
        "peak_pss_reduction_percent": _reduction(
            float(bf16["memory"]["peak_pss_bytes"]),
            float(enabled["memory"]["peak_pss_bytes"]),
        ),
        "weighted_pss_reduction_percent": _reduction(
            float(bf16["memory"]["time_weighted_pss_bytes"]),
            float(enabled["memory"]["time_weighted_pss_bytes"]),
        ),
        "migration_bf16_quality_correct": int(bf16["quality"]["correct"]),
        "migration_int4_quality_correct": int(enabled["quality"]["correct"]),
        "migration_quality_total": int(enabled["quality"]["total"]),
        "direct_shape_gains": gains,
        "direct_shapes": shapes,
    }
    comparisons = {
        "disk_reduction_percent": result["disk_reduction_percent"],
        "peak_pss_reduction_percent": result["peak_pss_reduction_percent"],
        "weighted_pss_reduction_percent": result["weighted_pss_reduction_percent"],
        "kleidiai_shape_gains": result["direct_shape_gains"],
    }
    for key, observed in comparisons.items():
        recorded = stored.get(key)
        observed_values = observed if isinstance(observed, list) else [observed]
        recorded_values = recorded if isinstance(recorded, list) else [recorded]
        if len(observed_values) != len(recorded_values) or any(
            not math.isclose(float(left), float(right), rel_tol=1e-12)
            for left, right in zip(observed_values, recorded_values, strict=True)
        ):
            raise ValueError(f"supporting summary disagrees with raw measurements: {key}")
    return result
