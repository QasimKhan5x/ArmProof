# ArmProof Adoption Checklist

- [ ] Replace the sample workload with representative requests.
- [ ] Pin model, runtime, environment and service commands.
- [ ] Set a service-level objective and claim threshold before testing.
- [ ] Run `python3 refresh_bindings.py` after replacing placeholders and before collecting evidence.
- [ ] Collect at least three passing and failing boundary confirmations.
- [ ] Keep confirmation files distinct and preserve open-loop timestamps.
- [ ] Capture positive and negative Arm execution profiles separately.
- [ ] Bind parser-ready profiler reports to the treatment identities.
- [ ] Collect raw HTTP quality responses from the same labeled dataset.
- [ ] Rerun `python3 refresh_bindings.py` after profiler capture to bind report hashes.
- [ ] Run `armproof seal armproof.json` after collection.
- [ ] If the contract changes again, rerun `python3 refresh_bindings.py`.
- [ ] Run `armproof ci armproof.json`; missing evidence must block.
