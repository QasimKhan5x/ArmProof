"""Small, fail-closed helpers for native Arm Performix run evidence."""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any


def _objects(text: str) -> Iterator[dict[str, Any]]:
    decoder = json.JSONDecoder()
    offset = 0
    while offset < len(text):
        start = text.find("{", offset)
        if start < 0:
            return
        try:
            value, consumed = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            offset = start + 1
            continue
        offset = start + consumed
        if isinstance(value, dict):
            yield value


def _run_ids(value: Any) -> Iterator[str]:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"run_id", "runId", "RunId"}:
                if isinstance(child, str) and child:
                    yield child
                elif isinstance(child, dict):
                    identifier = child.get("value")
                    if isinstance(identifier, str) and identifier:
                        yield identifier
            yield from _run_ids(child)
    elif isinstance(value, list):
        for child in value:
            yield from _run_ids(child)


def extract_run_id(output: str) -> str:
    """Return the final run ID from streamed APX JSON or fail closed."""
    identifiers = [identifier for obj in _objects(output) for identifier in _run_ids(obj)]
    if not identifiers:
        raise ValueError("Performix output contains no run_id")
    if len(set(identifiers)) != 1:
        raise ValueError(f"Performix output contains conflicting run IDs: {identifiers}")
    return identifiers[-1]
