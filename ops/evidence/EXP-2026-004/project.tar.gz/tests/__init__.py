"""ArmProof test suite."""
