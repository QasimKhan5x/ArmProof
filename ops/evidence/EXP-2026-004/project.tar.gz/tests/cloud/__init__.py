"""Cloud lifecycle tests."""
