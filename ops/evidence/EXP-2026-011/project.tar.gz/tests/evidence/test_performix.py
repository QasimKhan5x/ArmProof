from __future__ import annotations

import unittest

from armproof.evidence.performix import extract_run_id


class PerformixOutputTests(unittest.TestCase):
    def test_extracts_run_id_from_streamed_progress(self) -> None:
        output = "\n".join(
            [
                '{"data":{"stage":"collect","progress":10,"run_id":{"value":"run-42"}}}',
                '{"data":{"stage":"complete","progress":100,"run_id":{"value":"run-42"}}}',
            ]
        )
        self.assertEqual(extract_run_id(output), "run-42")

    def test_extracts_string_run_id_from_wrapped_response(self) -> None:
        self.assertEqual(
            extract_run_id('{"code":"0","data":{"run_id":"run-7"}}'), "run-7"
        )

    def test_rejects_missing_or_conflicting_run_ids(self) -> None:
        with self.assertRaisesRegex(ValueError, "no run_id"):
            extract_run_id('{"data":{"stage":"prepare"}}')
        with self.assertRaisesRegex(ValueError, "conflicting"):
            extract_run_id('{"run_id":"one"}\n{"run_id":"two"}')
