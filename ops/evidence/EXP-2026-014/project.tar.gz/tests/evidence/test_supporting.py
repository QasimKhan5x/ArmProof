from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from armproof.evidence.supporting import derive_supporting_optimization


ROOT = Path(__file__).resolve().parents[2]


class SupportingEvidenceTests(unittest.TestCase):
    def test_real_supporting_measurements_are_rederived(self) -> None:
        result = derive_supporting_optimization(
            ROOT / "ops/evidence/result-first/EXP-2026-002",
            ROOT / "examples/armproof-reference/supporting-evidence-lock.json",
        )
        self.assertEqual(len(result["direct_shape_gains"]), 4)
        self.assertGreater(min(result["direct_shape_gains"]), 1.7)
        self.assertGreater(result["disk_reduction_percent"], 35)
        self.assertGreater(result["peak_pss_reduction_percent"], 55)

    def test_changed_summary_is_rejected_by_the_lock(self) -> None:
        source = ROOT / "examples/armproof-reference/supporting-evidence-lock.json"
        with tempfile.TemporaryDirectory() as directory:
            lock = json.loads(source.read_text(encoding="utf-8"))
            lock["files"]["summary.json"] = "0" * 64
            changed = Path(directory) / "lock.json"
            changed.write_text(json.dumps(lock), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "digest mismatch"):
                derive_supporting_optimization(
                    ROOT / "ops/evidence/result-first/EXP-2026-002", changed
                )


if __name__ == "__main__":
    unittest.main()
