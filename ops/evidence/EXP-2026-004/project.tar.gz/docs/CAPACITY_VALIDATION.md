# Fixed-SLO Capacity Validation

## Status

Required before the polished report and GitHub integration become the critical
path. The underlying KleidiAI mechanism is already established.

## Question

Does the existing KleidiAI acceleration produce materially higher sustainable
cloud-service throughput at the same p95 SLO?

## Treatments

- Phi-4 Mini INT4 ONNX Runtime GenAI with KleidiAI disabled.
- Identical model, runtime, service, thread settings and workload with
  KleidiAI enabled.

PyTorch BF16 is retained for whole-deployment memory, size and quality context,
not the Arm causal throughput comparison.

## Workload

- Public licensed task data.
- Frozen short, long and mixed prompt mixes.
- Deterministic generation and output parser.
- At least 500 quality requests; 1,000 preferred.
- At least five capacity runs per treatment and mix.

## Primary Gate

- Minimum: 1.5x sustainable accepted throughput at the same p95 SLO in at
  least two of three traffic mixes.
- Preferred headline: 1.7x.
- Lower 95% confidence bound above 1.15x.
- No quality difference between the enabled and disabled identical-runtime
  treatments.
- `kai_*` present only when enabled.

## Secondary Gates

- Non-profiler ArmProof overhead below 5%.
- No unexplained treatment configuration difference.
- Complete raw bundle and terminated AWS resources.
- Repetition validity and error rates satisfy the benchmark protocol.

## Outcome

- `PASS`: proceed with the Cloud AI capacity story.
- `FAIL`: existing size, PSS and direct-speed findings remain true, but the
  grand-prize product thesis must be reconsidered before UI investment.
- `INCONCLUSIVE`: diagnose noise and preregister one bounded rerun.

There is no fallback to a weaker product story hidden inside this experiment.

## Cost Boundary

One `c8g.4xlarge`, expected 60-90 minutes, hard stop at two hours, with a USD 2
compute target and the repository-wide cloud ceiling enforced.

