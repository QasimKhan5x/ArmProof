"""Treatment adapter tests."""
