"""Quality evaluator tests."""
