# ArmProof Adoption Checklist

- [ ] Replace the sample workload with representative requests.
- [ ] Pin model, runtime, environment and service commands.
- [ ] Set a service-level objective and claim threshold before testing.
- [ ] Collect at least three passing and failing boundary confirmations.
- [ ] Keep confirmation files distinct and preserve open-loop timestamps.
- [ ] Capture positive and negative Arm execution profiles separately.
- [ ] Bind parser-ready profiler reports to the treatment identities.
- [ ] Collect raw HTTP quality responses from the same labeled dataset.
- [ ] Copy the three JSON templates into the exact evidence paths and replace every placeholder.
- [ ] Run `armproof seal armproof.json` after collection.
- [ ] After editing `contract.json`, update `contract-sha256` in the workflow.
- [ ] Run `armproof ci armproof.json`; missing evidence must block.
