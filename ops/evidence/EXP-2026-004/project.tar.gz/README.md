# ArmProof

ArmProof is a fail-closed CI release gate for Arm AI optimization pull
requests. It approves a deployment only when the submitted evidence shows that
the change:

- preserves the workload's declared quality contract;
- improves its declared cloud-serving objective;
- executes the required Arm acceleration path; and
- can be reproduced from pinned artifacts and commands.

The reference path migrates Phi-4 Mini from PyTorch BF16 to INT4 ONNX Runtime
GenAI with KleidiAI on AWS Graviton4. Existing experiments have already shown:

- 35.92% smaller INT4 artifacts than BF16;
- 55.34% lower peak PSS and 59.66% lower time-weighted PSS;
- 1.72x to 2.59x end-to-end speedup from KleidiAI enabled versus disabled in
  the identical INT4 model and runtime;
- 20/24 versus 19/24 quality results; and
- `kai_*` callchains only in the enabled treatment.

Those results establish the optimization mechanism. The remaining performance
gate is fixed-SLO serving capacity under concurrent traffic.

## Product Workflow

```text
optimization PR + armproof.yaml
              |
              v
matched baseline/treatment runs on Graviton
              |
              v
fail-closed claim ledger
              |
              +--> GitHub Check: pass/fail
              +--> interactive evidence report
              +--> reproducible deployment manifest
```

The intended interface is:

```bash
armproof run armproof.yaml
armproof verify evidence/run-id
armproof report evidence/run-id --output report/
armproof ci armproof.yaml
```

These commands are product contracts until the bootstrap task marks them
implemented and verified.

## Current Build

The repository now contains the imported result-first evidence, strict public
schemas, artifact fingerprints, seeded bootstrap statistics, a fail-closed
claim engine, the common Phi-4 HTTP service, and fixed-SLO load primitives.

```bash
make check
PYTHONPATH=src python3.12 -m armproof.cli verify \
  --contract examples/fixture-pass/contract.json \
  --comparison examples/fixture-pass/comparison.json
```

The real Phi-4 network smoke and concurrent Graviton capacity result are still
pending. Report UI and GitHub integration remain deliberately gated on that
result.

## Start Here

- Current state: [`STATUS.md`](STATUS.md)
- Agent rules: [`AGENTS.md`](AGENTS.md)
- Product specification: [`docs/PRODUCT_SPEC.md`](docs/PRODUCT_SPEC.md)
- Established evidence: [`docs/ESTABLISHED_EVIDENCE.md`](docs/ESTABLISHED_EVIDENCE.md)
- Architecture: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)
- Requirements: [`docs/REQUIREMENTS.md`](docs/REQUIREMENTS.md)
- Implementation plan: [`tasks/plan.md`](tasks/plan.md)
- Project routing map: [`docs/PROJECT_MAP.md`](docs/PROJECT_MAP.md)

## Claim Boundary

ArmProof is not an Arm certification authority and does not prove universal
model quality or optimality. It evaluates a declared contract for a pinned
model, workload, runtime and machine. User-facing copy must say "verified by
ArmProof," never "Arm certified."
