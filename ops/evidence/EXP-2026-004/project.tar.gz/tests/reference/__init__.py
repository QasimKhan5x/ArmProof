"""Reference integration tests."""
