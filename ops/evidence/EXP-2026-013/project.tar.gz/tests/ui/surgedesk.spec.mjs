import { test, expect } from "@playwright/test";
import { mkdir, readFile } from "node:fs/promises";


const appUrl = "http://127.0.0.1:8765/surgedesk/";
const demoData = JSON.parse(await readFile("surgedesk/data.json", "utf8"));


function captureBrowserErrors(page) {
  const messages = [];
  page.on("console", (message) => {
    if (["error", "warning"].includes(message.type())) messages.push(message.text());
  });
  page.on("pageerror", (error) => messages.push(error.message));
  return messages;
}


function auditReceipt() {
  const mixed = demoData.capacity.mixes.mixed;
  const proof = demoData.proof;
  const evidence = demoData.provenance.evidence;
  return {
    passed: true,
    experiment_id: demoData.provenance.experiment_id,
    adapter: proof.adapter_id,
    claims_verified: proof.verified_claims,
    claims: proof.claims,
    raw_request_outcomes: evidence.sustained_raw_confirmation_samples,
    raw_quality_outputs: evidence.raw_quality_outputs,
    confirmation_files: evidence.sustained_raw_confirmation_files,
    archive_sha256: evidence.sustained_archive_sha256,
    matched_control: true,
    deployment_identity: proof.live_deployment_identity,
    capacity: {
      trial_matrix: mixed.trial_matrix,
      optimized_pass_rps: mixed.optimized_sustainable_rps,
      baseline_fail_rps: mixed.baseline_fail_rps,
      minimum_ratio: mixed.minimum_capacity_ratio,
      confirmations: mixed.confirmations_per_treatment,
      confirmation_seconds: mixed.confirmation_seconds,
      rate_selection: demoData.capacity.rate_selection,
    },
    arm: {
      performix_disabled_sample_share_percent: proof.performix.disabled_kai_sample_share_percent,
      performix_enabled_sample_share_percent: proof.performix.enabled_kai_sample_share_percent,
      linux_perf_cycle_share_percent: proof.kleidiai_cycle_callchain_share_percent,
      kernel: proof.performix.kernel_family,
      engine_version: proof.performix.engine_version,
      cpu: proof.performix.cpu,
      enabled_function_samples: proof.performix.enabled_function_samples,
      scope_note: proof.performix.scope_note,
      pmu_capability_note: proof.performix.pmu_capability_note,
    },
    supporting: {
      direct_speedup_min: proof.direct_speedup_min,
      direct_speedup_max: proof.direct_speedup_max,
      direct_shape_gains: proof.direct_shape_gains,
      artifact_reduction_percent: proof.artifact_reduction_percent,
      peak_pss_reduction_percent: proof.peak_pss_reduction_percent,
      migration_quality_delta_pp: proof.migration_quality_delta_pp,
      migration_int4_quality_correct: proof.migration_int4_quality_correct,
      migration_bf16_quality_correct: proof.migration_bf16_quality_correct,
      migration_quality_total: proof.migration_quality_total,
    },
    elapsed_ms: 147.2,
  };
}


async function mockLiveGateway(page) {
  let activeLane = "baseline";
  const runtime = demoData.proof.live_deployment_identity;
  await page.route("**/surgedesk/live-status.json", (route) => route.fulfill({
    contentType: "application/json",
    body: JSON.stringify({
      live_available: true,
      matched_lanes_available: true,
      audit_available: true,
      mode: "live",
      deployment: {
        active_lane: activeLane,
        release_ready: false,
        audit_experiment_id: null,
        promoted_at: null,
      },
      matched_status: "matched",
      lanes: {
        baseline: { backend: "kleidiai-disabled", core_group: "0-15" },
        optimized: { backend: "kleidiai-enabled", core_group: "0-15" },
      },
    }),
  }));
  await page.route("**/api/audit", (route) => route.fulfill({
    contentType: "application/json",
    body: JSON.stringify(auditReceipt()),
  }));
  await page.route("**/api/promote", (route) => {
    activeLane = "optimized";
    return route.fulfill({
      contentType: "application/json",
      body: JSON.stringify({
        active_lane: activeLane,
        release_ready: true,
        audit_experiment_id: demoData.provenance.experiment_id,
        promoted_at: "2026-08-04T12:05:00.000Z",
        backend: "kleidiai-enabled",
        core_group: "0-15",
        runtime_identity: {
          source_artifact_sha256: runtime.source_artifact_sha256,
          runtime: runtime.runtime,
          runtime_version: runtime.runtime_version,
        },
      }),
    });
  });
  await page.route("**/api/route", (route) => {
    const request = route.request().postDataJSON();
    const optimized = activeLane === "optimized";
    return route.fulfill({
      contentType: "application/json",
      body: JSON.stringify({
        request_id: `live-${activeLane}`,
        source_text: request.text,
        suggested_intent: optimized
          ? "cash_withdrawal_not_recognised"
          : "lost_or_stolen_card",
        suggested_label: optimized
          ? "Cash Withdrawal Not Recognised"
          : "Lost Or Stolen Card",
        llm_queue: "Account security",
        guard_queue: "Account security",
        queue: "Account security",
        guard_overrode: false,
        guard_margin: 9.2,
        priority: "Urgent",
        suggested_procedure: "Verify the customer and secure the account.",
        expected_procedure: null,
        queue_correct: null,
        correct: null,
        mode: "live_model_output",
        backend: optimized ? "kleidiai-enabled" : "kleidiai-disabled",
        inference_ms: optimized ? 210.4 : 431.8,
        gateway_latency_ms: optimized ? 224.8 : 446.1,
        deployment_lane: activeLane,
        release_audit_id: optimized ? demoData.provenance.experiment_id : null,
      }),
    });
  });
}


test("a live ticket causes the audit, activation, and optimized second route", async ({ page }) => {
  const messages = captureBrowserErrors(page);
  await mockLiveGateway(page);
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto(appUrl);

  await page.getByLabel("Live matched Arm64 endpoint").check();
  await page.locator("#customer-message").fill(
    "My card was stolen while I am travelling. Freeze it and help me replace it.",
  );
  await page.getByRole("button", { name: "Run live route" }).click();
  await expect(page.locator("#inference-source")).toContainText("kleidiai-disabled");
  await page.locator("#final-queue").selectOption("Account security");
  await page.getByRole("button", { name: "Route ticket" }).click();
  await page.getByRole("button", { name: "Review measured upgrade" }).click();

  await expect(page.locator("#experiment-results")).toBeHidden();
  await expect(page.locator("#optimization-summary")).toBeHidden();
  await page.getByRole("button", { name: "Verify measured experiment" }).click();
  await expect(page.locator("#audit-receipt")).toBeVisible();
  await expect(page.locator("#audit-request-result")).toContainText("2,100 capacity requests");
  await expect(page.locator("#audit-request-result")).toContainText("1,540 model outputs");
  await expect(page.locator("#trial-matrix-body tr")).toHaveCount(2);
  await expect(page.locator("#trial-matrix-body tr").nth(0).locator(".fail")).toHaveCount(5);
  await expect(page.locator("#trial-matrix-body tr").nth(1).locator(".pass")).toHaveCount(5);
  await expect(page.locator("#headline-ratio")).toHaveText("≥2.00×");

  await page.getByRole("button", { name: "Review and activate the optimized service" }).click();
  await expect(page.locator("#optimization-summary")).toBeVisible();
  await expect(page.locator("#performix-proof")).toBeVisible();
  await page.getByRole("button", { name: "Activate verified optimized service" }).click();
  await expect(page.locator("#promotion-result")).toContainText("now serving");
  await page.getByRole("button", { name: "Route the next live request" }).click();
  await page.locator("#customer-message").fill(
    "My physical card is about to expire. How do I replace it?",
  );
  await page.getByRole("button", { name: "Run live route" }).click();
  await expect(page.locator("#inference-source")).toContainText("kleidiai-enabled");
  await page.locator("#final-queue").selectOption("Cards & payments");
  await page.getByRole("button", { name: "Route ticket" }).click();
  await expect(page.locator("#reviewed-tickets")).toContainText("Standard service");
  await expect(page.locator("#reviewed-tickets")).toContainText("Optimized service");
  await expect(page.locator("#reviewed-tickets")).toContainText(demoData.provenance.experiment_id);
  await expect(page.locator("#adoption-handoff")).toBeVisible();
  await page.getByRole("button", { name: "Carry this release gate to another service" }).click();
  await expect(page.locator("#proof-details")).toHaveAttribute("open", "");
  await expect(page.locator("#adoption-result")).toBeVisible();
  await expect(page.locator("#adoption-gate")).toContainText("BLOCKED");
  await expect(page.locator("#adoption-workflow")).toContainText("QasimKhan5x/ArmProof@v0.8.0");

  await mkdir("build/screenshots", { recursive: true });
  await page.screenshot({ path: "build/screenshots/surgedesk-live-flow.png", fullPage: true });
  expect(messages).toEqual([]);
});


test("public mode reveals checked-in proof only after the visitor requests it", async ({ page }) => {
  const messages = captureBrowserErrors(page);
  await page.route("**/surgedesk/live-status.json", (route) => route.fulfill({
    contentType: "application/json",
    body: JSON.stringify({
      audit_available: false,
      live_available: false,
      matched_lanes_available: false,
      mode: "recorded",
      deployment: {},
      lanes: {},
    }),
  }));
  await page.goto(`${appUrl}#surge`);
  await expect(page.locator("#experiment-results")).toBeHidden();
  await page.getByRole("button", { name: "Open checked-in evidence" }).click();
  await expect(page.locator("#audit-receipt")).toBeVisible();
  await expect(page.locator("#trial-matrix-body tr")).toHaveCount(2);
  await expect(page.locator("#headline-ratio")).toHaveText("≥2.00×");
  await page.getByRole("tab", { name: "Release" }).click();
  await expect(page.locator("#optimization-summary")).toBeVisible();
  await expect(page.locator("#proof-claims tr")).toHaveCount(10);
  await expect(page.locator("body")).not.toContainText(/tamper|altered archive/i);
  expect(messages).toEqual([]);
});


test("recorded support examples remain human-confirmed and clearly labeled", async ({ page }) => {
  await page.goto(appUrl);
  await expect(page.getByRole("heading", { name: "Route an incoming request" })).toBeVisible();
  await expect(page.locator(".routing-quality-details")).not.toHaveAttribute("open", "");
  await page.getByRole("button", { name: "Guard intervention" }).click();
  await page.getByRole("button", { name: "Inspect stored output" }).click();
  await expect(page.locator("#review-warning")).toContainText("routing guard changed");
  await expect(page.locator("#inference-source")).toContainText("Recorded");
  await page.getByRole("button", { name: "Route ticket" }).click();
  await expect(page.locator("#reviewed-tickets")).toContainText("Confirmed");
});


test("mobile public evidence remains readable without horizontal overflow", async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 780 });
  await page.route("**/surgedesk/live-status.json", (route) => route.fulfill({
    contentType: "application/json",
    body: JSON.stringify({ audit_available: false, live_available: false }),
  }));
  await page.goto(`${appUrl}#surge`);
  await page.getByRole("button", { name: "Open checked-in evidence" }).click();
  expect(await page.evaluate(
    () => document.documentElement.scrollWidth <= document.documentElement.clientWidth,
  )).toBe(true);
  await mkdir("build/screenshots", { recursive: true });
  await page.screenshot({ path: "build/screenshots/surgedesk-mobile.png", fullPage: true });
});
