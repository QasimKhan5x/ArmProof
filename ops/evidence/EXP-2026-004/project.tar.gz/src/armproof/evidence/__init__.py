"""Evidence collection, manifests, and verification."""

from armproof.evidence.manifest import build_manifest, verify_manifest
from armproof.evidence.records import EvidenceRecordError, parse_comparison
from armproof.evidence.identity import ArtifactFingerprint, fingerprint_path

__all__ = [
    "EvidenceRecordError",
    "ArtifactFingerprint",
    "build_manifest",
    "parse_comparison",
    "fingerprint_path",
    "verify_manifest",
]
