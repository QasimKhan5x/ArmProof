"""Report presenter tests."""
