"""ArmProof command-line entry point."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Sequence

from armproof.contracts import ContractError, parse_contract
from armproof.evidence import EvidenceRecordError, parse_comparison
from armproof.policy import decision_to_dict, evaluate_claims
from armproof.quality import evaluate_quality, load_quality_cases, quality_to_dict
from armproof.workload import (
    SloPolicy,
    capacity_to_dict,
    find_sustainable_capacity,
    load_requests_jsonl,
    materialize_requests,
    run_closed_loop,
    run_open_loop,
    write_samples_jsonl,
)
from armproof.workload.load import send_http_json


def _json_object(path: Path) -> dict:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return payload


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="armproof")
    subparsers = parser.add_subparsers(dest="command", required=True)
    verify = subparsers.add_parser("verify", help="evaluate claims from normalized evidence")
    verify.add_argument("--contract", type=Path, required=True)
    verify.add_argument("--comparison", type=Path, action="append", required=True)
    verify.add_argument("--output", type=Path)
    capacity = subparsers.add_parser("capacity", help="run a fixed-SLO HTTP capacity search")
    capacity.add_argument("--endpoint", required=True)
    capacity.add_argument("--workload", type=Path, required=True)
    capacity.add_argument("--candidates-rps", required=True, help="ascending comma-separated values")
    capacity.add_argument("--measurement-seconds", type=float, required=True)
    capacity.add_argument("--p95-slo-ms", type=float, required=True)
    capacity.add_argument("--max-error-rate", type=float, default=0.01)
    capacity.add_argument("--workers", type=int, default=64)
    capacity.add_argument("--request-timeout", type=float, default=30.0)
    capacity.add_argument("--output", type=Path, required=True)
    quality = subparsers.add_parser("quality", help="run and score a BANKING77 quality set")
    quality.add_argument("--endpoint", required=True)
    quality.add_argument("--dataset", type=Path, required=True)
    quality.add_argument("--concurrency", type=int, default=4)
    quality.add_argument("--request-timeout", type=float, default=30.0)
    quality.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "capacity":
        return _run_capacity(args)
    if args.command == "quality":
        return _run_quality(args)
    try:
        contract = parse_contract(_json_object(args.contract))
        comparisons = [parse_comparison(_json_object(path)) for path in args.comparison]
    except (ValueError, ContractError, EvidenceRecordError) as exc:
        print(f"armproof: {exc}", file=sys.stderr)
        return 1
    decision = decision_to_dict(evaluate_claims(contract.claims, comparisons))
    rendered = json.dumps(decision, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0 if decision["passed"] else 2


def _run_capacity(args: argparse.Namespace) -> int:
    try:
        candidates = [float(item) for item in args.candidates_rps.split(",")]
        base = load_requests_jsonl(args.workload)
        if args.measurement_seconds <= 0:
            raise ValueError("measurement-seconds must be positive")
        samples_by_target = {}

        def run_candidate(target_rps: float):
            count = max(1, math.ceil(target_rps * args.measurement_seconds))
            requests = materialize_requests(base, count, f"rps-{target_rps:g}")
            samples = run_open_loop(
                requests,
                lambda item, scheduled: send_http_json(
                    args.endpoint, item, scheduled, args.request_timeout
                ),
                target_rps=target_rps,
                max_workers=args.workers,
            )
            samples_by_target[target_rps] = samples
            return samples

        result = find_sustainable_capacity(
            candidates,
            run_candidate,
            SloPolicy(args.p95_slo_ms, args.max_error_rate),
            args.measurement_seconds,
        )
    except (OSError, ValueError) as exc:
        print(f"armproof: {exc}", file=sys.stderr)
        return 1
    args.output.mkdir(parents=True, exist_ok=True)
    for target, samples in samples_by_target.items():
        write_samples_jsonl(args.output / f"requests-rps-{target:g}.jsonl", samples)
    rendered = json.dumps(capacity_to_dict(result), indent=2, sort_keys=True) + "\n"
    (args.output / "capacity.json").write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if result.sustainable_rps > 0 else 2


def _run_quality(args: argparse.Namespace) -> int:
    try:
        cases = load_quality_cases(args.dataset)
        samples = run_closed_loop(
            [case.request for case in cases],
            lambda item, scheduled: send_http_json(
                args.endpoint, item, scheduled, args.request_timeout
            ),
            args.concurrency,
        )
        result = evaluate_quality(cases, samples)
    except (OSError, ValueError) as exc:
        print(f"armproof: {exc}", file=sys.stderr)
        return 1
    args.output.mkdir(parents=True, exist_ok=True)
    write_samples_jsonl(args.output / "quality-samples.jsonl", samples)
    rendered = json.dumps(quality_to_dict(result), indent=2, sort_keys=True) + "\n"
    (args.output / "quality.json").write_text(rendered, encoding="utf-8")
    summary = {
        "accuracy": result.accuracy,
        "macro_f1": result.macro_f1,
        "schema_valid_rate": result.schema_valid_rate,
        "total": result.total,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if result.schema_valid_rate >= 0.99 and result.missing == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
