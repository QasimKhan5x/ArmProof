from __future__ import annotations

import json
import threading
import unittest
import urllib.request
from contextlib import ExitStack, contextmanager
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Iterator
from unittest.mock import patch

from scripts.serve_surgedesk import handler_for


SOURCE_SHA = "9ef697ababdc0b4ffc63b098bbd4760f79795eb0502ca4d41c80e20843ac0ab1"


def _lane_handler(backend: str, control: str) -> type[BaseHTTPRequestHandler]:
    identity = {
        "model_identity": "a" * 64,
        "source_artifact_sha256": SOURCE_SHA,
        "runtime": "onnxruntime-genai",
        "runtime_version": "0.15.0.dev0",
        "threads": 16,
        "architecture": "aarch64",
        "cpu_affinity": list(range(16)),
        "optimization_control": {"mlas.disable_kleidiai": control},
    }

    class LaneHandler(BaseHTTPRequestHandler):
        def log_message(self, _format: str, *args: object) -> None:
            return

        def _json(self, status: HTTPStatus, payload: dict[str, Any]) -> None:
            body = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            if self.path != "/health":
                self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})
                return
            self._json(HTTPStatus.OK, {"ready": True, "backend": backend, **identity})

        def do_POST(self) -> None:
            if self.path != "/infer":
                self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})
                return
            request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            self._json(HTTPStatus.OK, {
                "request_id": request["request_id"],
                "backend": backend,
                "output": '{"intent":"lost_or_stolen_card"}',
                "inference_ms": 3.0,
                "runtime_identity": identity,
            })

    return LaneHandler


@contextmanager
def _server(handler: type[BaseHTTPRequestHandler]) -> Iterator[ThreadingHTTPServer]:
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield server
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()


def _request(url: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    body = json.dumps(payload).encode() if payload is not None else b""
    request = urllib.request.Request(
        f"{url}{path}",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=5) as response:
        return json.load(response)


def _audit_payload() -> dict[str, Any]:
    identity = {
        "source_artifact_sha256": SOURCE_SHA,
        "runtime_lock_sha256": "68a4aa0e9b52bfacd435b1515aa5cc34acb760ba63961ddf70f6b0b01c96a884",
        "runtime": "onnxruntime-genai",
        "runtime_version": "0.15.0.dev0",
        "architecture": "aarch64",
        "threads": 16,
        "instance_type": "c8g.4xlarge",
        "controls": {
            "baseline": {"mlas.disable_kleidiai": "1"},
            "optimized": {"mlas.disable_kleidiai": "0"},
        },
    }
    return {
        "proof": {
            "decision": "PASS",
            "adapter_id": "kleidiai-confirmed-v2",
            "verified_claims": 1,
            "claims": [{"status": "pass"}],
            "live_deployment_identity": identity,
            "performix": {
                "disabled_kai_sample_share_percent": 0.0,
                "enabled_kai_sample_share_percent": 67.0,
                "kernel_family": "kai_kernel_matmul_neon_i8mm",
            },
            "kleidiai_cycle_callchain_share_percent": 68.0,
        },
        "capacity": {"mixes": {"mixed": {
            "trial_matrix": [],
            "optimized_sustainable_rps": 0.56,
            "baseline_fail_rps": 0.28,
            "minimum_capacity_ratio": 2.0,
            "confirmations_per_treatment": 5,
            "confirmation_seconds": 500,
        }}},
        "provenance": {
            "experiment_id": "EXP-2026-012",
            "evidence": {
                "sustained_raw_confirmation_samples": 2100,
                "sustained_raw_confirmation_files": 10,
                "raw_quality_outputs": 1540,
                "sustained_archive_sha256": "b" * 64,
                "sustained_matched_control_verified": True,
            },
        },
    }


class SurgeDeskGatewayEndToEndTests(unittest.TestCase):
    def test_real_http_flow_routes_control_then_audited_treatment(self) -> None:
        with ExitStack() as stack:
            baseline = stack.enter_context(
                _server(_lane_handler("kleidiai-disabled", "1"))
            )
            optimized = stack.enter_context(
                _server(_lane_handler("kleidiai-enabled", "0"))
            )
            gateway_handler = handler_for(
                baseline_endpoint=f"http://127.0.0.1:{baseline.server_port}/infer",
                optimized_endpoint=f"http://127.0.0.1:{optimized.server_port}/infer",
                baseline_cores="0-15",
                optimized_cores="0-15",
            )
            gateway = stack.enter_context(_server(gateway_handler))
            root = f"http://127.0.0.1:{gateway.server_port}"

            first = _request(root, "/api/route", {"text": "My card was stolen"})
            self.assertEqual(first["backend"], "kleidiai-disabled")
            self.assertEqual(first["deployment_lane"], "baseline")
            self.assertIsNone(first["release_audit_id"])

            with patch(
                "scripts.serve_surgedesk.build_surgedesk_payload",
                return_value=_audit_payload(),
            ):
                receipt = _request(root, "/api/audit")
            self.assertTrue(receipt["passed"])
            promoted = _request(root, "/api/promote")
            self.assertEqual(promoted["active_lane"], "optimized")
            self.assertEqual(promoted["runtime_identity"]["source_artifact_sha256"], SOURCE_SHA)

            second = _request(root, "/api/route", {"text": "That cash withdrawal was not mine"})
            self.assertEqual(second["backend"], "kleidiai-enabled")
            self.assertEqual(second["deployment_lane"], "optimized")
            self.assertEqual(second["release_audit_id"], "EXP-2026-012")


if __name__ == "__main__":
    unittest.main()
