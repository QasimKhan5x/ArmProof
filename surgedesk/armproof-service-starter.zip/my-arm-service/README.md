# ArmProof HTTP Starter

Target endpoint: `http://127.0.0.1:8000/infer`

This scaffold intentionally contains no passing evidence. Start with `ADOPTION_CHECKLIST.md`, use the fixed-SLO collector, then place raw files under `evidence/`. Until that evidence is complete and checksum-bound, `armproof ci armproof.json` fails closed.

## Check The Empty Starter

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install git+https://github.com/QasimKhan5x/ArmProof.git@v0.9.0
.venv/bin/armproof ci armproof.json
```

The last command must fail because the starter has no measurements. Follow `EVIDENCE_LAYOUT.md` and `ADOPTION_CHECKLIST.md`. After collection:

```bash
.venv/bin/armproof seal armproof.json
.venv/bin/armproof ci armproof.json
```

Replace both workload templates and the identity-source placeholders before collecting evidence. The `templates/` directory contains exact parser-ready JSON shapes; the collection plan names every required output.

See the complete executable shape in the upstream `examples/http-slo/` directory.
