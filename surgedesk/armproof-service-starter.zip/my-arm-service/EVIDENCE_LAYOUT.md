# Evidence Layout

`collection-plan.json` contains these paths as machine-readable JSON. Collect each file from matched baseline and treatment runs; never reuse one confirmation under more than one name.

```text
evidence/
  protocol.json
  identities.json
  baseline.perf
  treatment.perf
  profiles/manifest.json
  quality/baseline-samples.jsonl
  quality/treatment-samples.jsonl
  requests/{baseline,treatment}-{pass,fail}-{1,2,3}.jsonl
  identity-sources/artifact.ref
  identity-sources/runtime.lock
  identity-sources/environment.json
  identity-sources/workload-manifest.json
  identity-sources/capacity.jsonl
  identity-sources/quality.jsonl
```

Start from `templates/protocol.json`, `templates/identities.json`, and `templates/profile-manifest.json`; copy them to the paths above and replace every placeholder with values from the measured runs. Copy the generated identity sources and workloads into the exact filenames shown.

Use `armproof capacity` and `armproof quality` for request and quality rows. Add parser-ready profiler reports and their identity-bound manifest, then run:

```bash
armproof seal armproof.json
armproof ci armproof.json
```

The templates use the exact parser shape. A complete measured example is executable under `examples/http-slo/` in the ArmProof repository.
