import { defineConfig } from '@playwright/test';

export default defineConfig({
  workers: 1,
  reporter: 'line',
  webServer: {
    command: 'PYTHONPATH=src python3.12 tests/fixtures/surgedesk_live_gateway.py',
    url: 'http://127.0.0.1:8876/surgedesk/',
    reuseExistingServer: false,
  },
  use: {
    browserName: 'chromium',
    headless: true,
  },
});
