# Three-Minute Demo And Recording Runbook

This document contains the complete setup, preflight, recording sequence and
cleanup. The browser begins with an empty live request. During the recording,
you type two customer messages, route the first through the control deployment,
activate the audited Arm treatment, and route the second through that treatment.

Target length: **2:35 to 2:50**. Keep ten seconds of margin for live inference.

Use the narration as a rehearsal guide and speak in your normal words while
recording. The screen actions and factual boundaries are the parts that must
remain exact.

## 1. Check The Repository

Run on the recording Mac from the repository root:

```bash
make check
npm run test:logic
npm run test:ui
PYTHONPATH=src python3.12 -m armproof.cli ci \
  examples/armproof-reference/armproof.json
```

Expected result: the Python, logic and browser suites pass, and ArmProof exits
with code `0` after approving every required claim in the confirmed contract.

## 2. Prepare A Graviton4 Host

Use Ubuntu 24.04 Arm64 on one AWS `c8g.4xlarge`. On the Mac, set these values:

This owner-only path requires authenticated AWS credentials, `c8g.4xlarge`
quota in the selected region, an SSH key, port-22 access from the recording
Mac, and the pinned runtime bundle produced during project setup. Judges can
verify the checked-in evidence without AWS access or this bundle.

```bash
export GRAVITON_HOST=ubuntu@YOUR_PUBLIC_DNS_NAME
export INSTANCE_ID=i-YOUR_INSTANCE_ID
export RUNTIME_BUNDLE="$(cd .. && pwd)/result-first-bakeoff/evidence/checkpoints/runtime-checkpoints.tar.gz"

test -f "$RUNTIME_BUNDLE"
ssh "$GRAVITON_HOST" 'uname -m'
```

Expected output from `uname -m`: `aarch64`.

Upload the pinned runtime and clone the project:

```bash
scp "$RUNTIME_BUNDLE" "$GRAVITON_HOST:~/runtime-checkpoints.tar.gz"
ssh "$GRAVITON_HOST" '
  if [ -d ~/ArmProof/.git ]; then
    git -C ~/ArmProof pull --ff-only
  else
    git clone https://github.com/QasimKhan5x/ArmProof.git ~/ArmProof
  fi
  ~/ArmProof/scripts/prepare_live_demo_host.sh
'
```

The final line must begin with `READY` and show the source-model SHA-256 plus
`threads=16`. The setup script compares the downloaded model fingerprint with
the artifact identity in the release before creating either treatment.

## 3. Start The Two Exact Treatment Configurations

Open two terminals on the Mac and leave these commands running.

Terminal A:

```bash
ssh -t "$GRAVITON_HOST" '~/ArmProof/scripts/run_live_demo_lane.sh baseline'
```

Terminal B:

```bash
ssh -t "$GRAVITON_HOST" '~/ArmProof/scripts/run_live_demo_lane.sh optimized'
```

Both services use all 16 Graviton4 cores because the long capacity experiment
also used 16 threads. The gateway sends ordinary product traffic to one active
lane at a time.

Open a third terminal for the tunnel:

```bash
ssh -N \
  -L 18001:127.0.0.1:8001 \
  -L 18002:127.0.0.1:8002 \
  "$GRAVITON_HOST"
```

## 4. Preflight The Live Endpoints

From the repository root on the Mac:

```bash
python3.12 scripts/demo_live_compare.py \
  --baseline-endpoint http://127.0.0.1:18001/infer \
  --optimized-endpoint http://127.0.0.1:18002/infer
```

Expected ending:

```text
READY matched endpoint identities verified; request latency is a warm-up observation.
```

Start a fresh gateway after the preflight. A new process resets the active lane
to the control and clears all release state:

```bash
python3.12 scripts/serve_surgedesk.py \
  --port 8765 \
  --baseline-endpoint http://127.0.0.1:18001/infer \
  --optimized-endpoint http://127.0.0.1:18002/infer \
  --baseline-cores 0-15 \
  --optimized-cores 0-15
```

Open <http://127.0.0.1:8765/surgedesk/#triage>. Select **Live Arm64
inference**, confirm that the message box is empty, then return focus to the
browser address bar. Do not enter either recording message during setup.

## 5. Record The Video

Record at 1440×900 or 1920×1080 with browser zoom at 100%. Hide bookmarks,
notifications and unrelated tabs. Keep terminals and AWS consoles outside the
capture. Move the pointer only when the next control is visible.

### 0:00-0:32 - Route A Live Request On The Standard Service

**Screen:** Start on the empty live request form. The deployment strip must say
**Standard service · KleidiAI off** and **Waiting for the measured release
check**.

Type:

```text
My card was stolen while I am travelling. Freeze it and help me replace it.
```

Click **Run live route**. Choose **Account security** as the final queue and
click **Route ticket**.

**Talking points:**

> SurgeDesk handles banking-support intake on a CPU-only Graviton4 server.
> Phi-4 classifies the intent, the application selects a procedure, a local
> guard proposes an operational queue, and the support agent makes the final
> decision. This request used the standard service with KleidiAI off. We have a
> faster candidate, but traffic stays here until its measured release passes.

### 0:32-0:55 - Recalculate The Published Result

Click **Review measured upgrade**, then **Verify measured experiment**. Wait for
the receipt and point to **2,100 capacity requests**, **1,540 model outputs** and
the required release-check count.

**Talking points:**

> The long traffic windows were collected before this recording. This action is
> reading their published raw rows now, measuring latency from each scheduled
> send through completion, checking every response's model and runtime identity,
> and recalculating the release decision. Missing or inconsistent evidence stops
> here and the standard service keeps serving.

### 0:55-1:25 - Show How The Rates Were Chosen

Scroll once to **Rate selection trail**, then to the five-by-five confirmation
table. Keep both transitions slow enough to read.

**Talking points:**

> The earlier discovery run found the standard service passing at 0.24 requests
> per second and failing at 0.28. The optimized service passed at 0.56; 0.60 was
> mixed, so we did not use it as an exact boundary. Before the confirmation
> server launched, we froze two one-sided checks: standard must fail at 0.28 and
> optimized must pass at 0.56. All five 500-second windows on each side matched
> those rules. The table shows every p95 result, not a selected best run.

### 1:25-1:52 - Connect Arm Execution To Service Capacity

Scroll to **What the confirmed capacity boundaries establish**, then to
**Evidence that KleidiAI ran**.

**Talking points:**

> The measured bounds are standard capacity below 0.28 and optimized capacity at
> or above 0.56, so the published improvement is the conservative lower bound:
> at least twice the sustained traffic on the same 16-core server. Arm Performix
> found no KleidiAI functions in the standard profile and more than half of the
> optimized profile's function samples in KleidiAI, including the Neoverse I8MM
> integer matrix kernel. A separate fixed-shape test also improved in all four
> cases; the four values are shown together in the release view.

### 1:52-2:10 - Activate The Exact Measured Service

Click **Review and activate the optimized service**, then **Activate verified
optimized service**. Wait for the activation message.

**Talking points:**

> Activation checks both running services again. Their source-model fingerprint,
> ONNX Runtime version, Arm64 architecture, 16-thread setup and opposite
> KleidiAI controls must match the release that just passed. They do, so the
> gateway switches this application to the optimized service.

### 2:10-2:36 - Route A Different Live Request After Activation

Click **Route the next live request** and type:

```text
My physical card is about to expire. How do I replace it?
```

Click **Run live route**, choose **Cards & payments**, and click **Route
ticket**. Point to **Served by** in the reviewed-ticket table.

**Talking points:**

> This second request used the optimized service. Its ticket row records
> KleidiAI on and the EXP-2026-012 release that authorized the change. The
> application behavior, deployment state and evidence now agree in one audit
> trail.

### 2:36-2:50 - Generate The Reusable Developer Starter

Click **Generate an ArmProof starter**. Wait for the generated-file count and
blocked first check to appear.

**Talking points:**

> ArmProof has just generated a contract, workload templates, evidence checklist
> and GitHub Action for another Arm AI service. Its first check blocks because
> that new project has no measurements yet; developers replace the templates,
> collect evidence and keep the same release rule in CI.

Stop recording on the generated workflow and blocked result.

## 6. Recording Accuracy

- The two support messages are live model inference and are typed during the video.
- The ten 500-second windows were collected before recording. The video reruns
  their verification from the checked-in archive.
- The capacity claim comes from the preregistered confirmation rates. Earlier
  discovery runs remain in the repository history and do not approve this release.
- INT4 size and memory results describe the BF16-to-INT4 migration. The
  two-times capacity result isolates KleidiAI within the matched INT4 runtime.
- Performix function samples and Linux perf cycle samples are reported as
  separate measurements.
- Human operators choose the final support queue. The queue guard is an
  application feature rather than part of the Arm speed claim.
- ArmProof evaluates this project's contract and evidence; it is not an Arm
  certification service.

## 7. Stop The Paid Host

Stop both service terminals, the SSH tunnel and the local gateway with
`Ctrl-C`, then terminate the instance:

```bash
aws ec2 terminate-instances \
  --region us-east-1 \
  --instance-ids "$INSTANCE_ID" \
  --query 'TerminatingInstances[0].[InstanceId,CurrentState.Name]' \
  --output text

aws ec2 wait instance-terminated \
  --region us-east-1 \
  --instance-ids "$INSTANCE_ID"
```

Expected first output: the instance ID followed by `shutting-down`.
