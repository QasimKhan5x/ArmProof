# Established Evidence

This document records accepted findings that predate the ArmProof product
implementation. It is a routing summary, not a substitute for raw evidence.

## Environment

- AWS Graviton4 `c8g.4xlarge`, CPU-only.
- Phi-4 Mini.
- PyTorch BF16 reference.
- ONNX Runtime GenAI INT4 treatment.
- Identical INT4 model/runtime with `mlas.disable_kleidiai=1` as the Arm
  acceleration control.

## Accepted Results

| Claim | Comparison | Result |
|---|---|---:|
| Artifact size | INT4 versus BF16 | 35.92% smaller |
| Peak PSS | INT4 versus BF16 | 55.34% lower |
| Time-weighted PSS | INT4 versus BF16 | 59.66% lower |
| KleidiAI end-to-end speed | enabled versus disabled, same INT4 runtime | 1.72x to 2.59x |
| Quality | INT4 versus BF16 | 20/24 versus 19/24 |
| Parseability | both | 24/24 |
| Arm attribution | enabled/disabled perf callchains | `kai_*` only when enabled |

The four accepted KleidiAI speedups cover batch/prompt shapes `(1,128)`,
`(1,512)`, `(4,128)` and `(4,512)`.

## Historical Qualification

The first experiment failed its frozen loaded-RSS gate because pre-inference
BF16 RSS did not represent resident model pages. That experiment remains a
no-go under its original rules. A separately preregistered follow-up sampled
`/proc/self/smaps_rollup` throughout inference and passed all nine gates. The
follow-up does not rewrite the original result.

## Current Evidence Location

During this context migration, summaries and raw archives remain in the sibling
workspace directory `../result-first-bakeoff` relative to the parent project
workspace. `EVID-001` must import selected immutable artifacts, hashes and
provenance into `ops/evidence/` before ArmProof treats the claims as portable
repository evidence.

## Not Yet Established

- Sustainable HTTP service throughput at a fixed p95 SLO.
- ArmProof measurement overhead.
- Clean reproduction from this Git repository.
- Quality non-inferiority on a larger public workload.
- GitHub Action and generated deployment behavior.

No document or report may present those as completed.
