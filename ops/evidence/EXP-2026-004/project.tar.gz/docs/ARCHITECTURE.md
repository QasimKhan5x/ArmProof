# ArmProof Architecture

## System Boundary

ArmProof orchestrates existing inference runtimes and profiling tools. It does
not implement model kernels, inference scheduling or model conversion.

```text
armproof.yaml
     |
     v
contract validator
     |
     v
experiment orchestrator
     |-- treatment adapters
     |-- workload/load generator
     |-- quality evaluator
     |-- resource sampler
     `-- Arm attribution collector
     |
     v
normalized evidence store
     |
     v
fail-closed claim ledger
     |-- CLI decision
     |-- GitHub Check
     |-- static report
     `-- deployment manifest
```

## Modules

### Contracts

Parses versioned YAML/JSON inputs, rejects unknown required semantics, and
normalizes them into immutable domain records.

### Treatment Adapters

One adapter owns process command construction, environment, readiness and
shutdown for one treatment. Reference adapters are:

- `pytorch_bf16`;
- `ort_int4_kleidiai_disabled`;
- `ort_int4_kleidiai_enabled`.

Enabled and disabled INT4 adapters must share every field except the explicit
KleidiAI control.

### Workload Runner

Replays frozen requests against a common HTTP interface. It records request
identity, scheduling time, response, status and latency. Traffic policies are
closed-loop smoke, fixed-rate SLO and saturation discovery.

### Collectors

- Process collector: lifecycle, exit status and logs.
- Memory collector: timestamped RSS/PSS from `smaps_rollup`.
- Performance collector: request latency, accepted throughput and errors.
- Arm collector: bounded `perf`/Performix capture and normalized `kai_*`
  execution status.
- Environment collector: CPU, ISA, OS, runtime and artifact identity.

Profiler collection is separate from normal load measurement so profiling
overhead does not contaminate the primary performance result.

### Quality Evaluator

Receives recorded outputs and a workload-specific metric plugin. It counts
malformed, missing and timed-out outputs as declared by the contract. The core
system does not encode support-routing semantics.

### Evidence Store

An append-only run directory contains raw samples, normalized records, hashes,
commands and logs. Normalized records reference raw evidence rather than copy
unverifiable prose.

### Claim Ledger

Pure policy code evaluates claims. A claim has a causal scope, comparison,
metric, threshold, evidence IDs and status: `pass`, `fail`, `unknown` or
`not_applicable`. Required `unknown` claims fail the contract.

### Presenters

CLI, GitHub and web report consume the same verified decision artifact. They
cannot independently reinterpret metrics.

## Repository Structure

```text
src/armproof/
  cli.py
  contracts/
  domain/
  adapters/
  workload/
  collectors/
  quality/
  evidence/
  policy/
  report/
tests/
  fixtures/
  contract/
  integration/
report-ui/
action/
examples/phi4-graviton/
schemas/
ops/evidence/
```

## Error Model

Errors use stable reason codes grouped as contract, execution, evidence,
attribution, quality and policy failures. Exceptions are not converted into
passing or partial decisions.

## Trust Boundaries

- Contract and workload content are untrusted input.
- Raw evidence is immutable after collection but not trusted until verified.
- Normalized evidence is derived and must retain provenance.
- The claim decision is trusted only after schema, hash and dependency checks.
- Report text is presentation, never authority.

## Deployment Output

The generated manifest pins the exact passing treatment identity, model,
runtime, environment variables, arguments and resource settings. It is not a
general deployment platform.
