import { test, expect } from "@playwright/test";
import { mkdir, readFile } from "node:fs/promises";


const appUrl = "http://127.0.0.1:8876/surgedesk/";
const demoData = JSON.parse(await readFile("surgedesk/data.json", "utf8"));


function captureBrowserErrors(page) {
  const messages = [];
  page.on("console", (message) => {
    if (["error", "warning"].includes(message.type())) messages.push(message.text());
  });
  page.on("pageerror", (error) => messages.push(error.message));
  return messages;
}


test("a live ticket causes the audit, activation, and optimized second route", async ({ page }) => {
  const messages = captureBrowserErrors(page);
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto(appUrl);

  await page.getByLabel("Live matched Arm64 endpoint").check();
  await page.locator("#customer-message").fill(
    "My card was stolen while I am travelling. Freeze it and help me replace it.",
  );
  await page.getByRole("button", { name: "Run live route" }).click();
  await expect(page.locator("#inference-source")).toContainText("kleidiai-disabled");
  await page.locator("#final-queue").selectOption("Account security");
  await page.getByRole("button", { name: "Route ticket" }).click();
  await page.getByRole("button", { name: "Review measured upgrade" }).click();

  await expect(page.locator("#experiment-results")).toBeHidden();
  await expect(page.locator("#optimization-summary")).toBeHidden();
  await page.getByRole("button", { name: "Verify measured experiment" }).click();
  await expect(page.locator("#audit-receipt")).toBeVisible();
  await expect(page.locator("#audit-request-result")).toContainText("2,100 capacity requests");
  await expect(page.locator("#audit-request-result")).toContainText("1,540 model outputs");
  await expect(page.locator("#trial-matrix-body tr")).toHaveCount(2);
  await expect(page.locator("#trial-matrix-body tr").nth(0).locator(".fail")).toHaveCount(5);
  await expect(page.locator("#trial-matrix-body tr").nth(1).locator(".pass")).toHaveCount(5);
  await expect(page.locator("#headline-ratio")).toHaveText("≥2.00×");

  await page.getByRole("button", { name: "Review and activate the optimized service" }).click();
  await expect(page.locator("#optimization-summary")).toBeVisible();
  await expect(page.locator("#performix-proof")).toBeVisible();
  await page.getByRole("button", { name: "Activate verified optimized service" }).click();
  await expect(page.locator("#promotion-result")).toContainText("now serving");
  await page.getByRole("button", { name: "Route the next live request" }).click();
  await page.locator("#customer-message").fill(
    "My physical card is about to expire. How do I replace it?",
  );
  await page.getByRole("button", { name: "Run live route" }).click();
  await expect(page.locator("#inference-source")).toContainText("kleidiai-enabled");
  await page.locator("#final-queue").selectOption("Cards & payments");
  await page.getByRole("button", { name: "Route ticket" }).click();
  await expect(page.locator("#reviewed-tickets")).toContainText("Standard service");
  await expect(page.locator("#reviewed-tickets")).toContainText("Optimized service");
  await expect(page.locator("#reviewed-tickets")).toContainText(demoData.provenance.experiment_id);
  await expect(page.locator("#adoption-handoff")).toBeVisible();
  await page.getByRole("button", { name: "Carry this release gate to another service" }).click();
  await expect(page.locator("#proof-details")).toHaveAttribute("open", "");
  await expect(page.locator("#adoption-result")).toBeVisible();
  await expect(page.locator("#adoption-gate")).toContainText("BLOCKED");
  await expect(page.locator("#adoption-workflow")).toContainText("QasimKhan5x/ArmProof@v0.8.0");

  await mkdir("build/screenshots", { recursive: true });
  await page.screenshot({ path: "build/screenshots/surgedesk-live-flow.png", fullPage: true });
  expect(messages).toEqual([]);
});


test("public mode reveals checked-in proof only after the visitor requests it", async ({ page }) => {
  const messages = captureBrowserErrors(page);
  await page.route("**/surgedesk/live-status.json", (route) => route.fulfill({
    contentType: "application/json",
    body: JSON.stringify({
      audit_available: false,
      live_available: false,
      matched_lanes_available: false,
      mode: "recorded",
      deployment: {},
      lanes: {},
    }),
  }));
  await page.goto(`${appUrl}#surge`);
  await expect(page.locator("#experiment-results")).toBeHidden();
  await page.getByRole("button", { name: "Open checked-in evidence" }).click();
  await expect(page.locator("#audit-receipt")).toBeVisible();
  await expect(page.locator("#trial-matrix-body tr")).toHaveCount(2);
  await expect(page.locator("#headline-ratio")).toHaveText("≥2.00×");
  await page.getByRole("tab", { name: "Release" }).click();
  await expect(page.locator("#optimization-summary")).toBeVisible();
  await expect(page.locator("#proof-claims tr")).toHaveCount(10);
  await expect(page.locator("body")).not.toContainText(/tamper|altered archive/i);
  expect(messages).toEqual([]);
});


test("recorded support examples remain human-confirmed and clearly labeled", async ({ page }) => {
  await page.goto(appUrl);
  await expect(page.getByRole("heading", { name: "Route an incoming request" })).toBeVisible();
  await expect(page.locator(".routing-quality-details")).not.toHaveAttribute("open", "");
  await page.getByRole("button", { name: "Guard intervention" }).click();
  await page.getByRole("button", { name: "Inspect stored output" }).click();
  await expect(page.locator("#review-warning")).toContainText("routing guard changed");
  await expect(page.locator("#inference-source")).toContainText("Recorded");
  await page.getByRole("button", { name: "Route ticket" }).click();
  await expect(page.locator("#reviewed-tickets")).toContainText("Confirmed");
});


test("mobile public evidence remains readable without horizontal overflow", async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 780 });
  await page.route("**/surgedesk/live-status.json", (route) => route.fulfill({
    contentType: "application/json",
    body: JSON.stringify({ audit_available: false, live_available: false }),
  }));
  await page.goto(`${appUrl}#surge`);
  await page.getByRole("button", { name: "Open checked-in evidence" }).click();
  expect(await page.evaluate(
    () => document.documentElement.scrollWidth <= document.documentElement.clientWidth,
  )).toBe(true);
  await mkdir("build/screenshots", { recursive: true });
  await page.screenshot({ path: "build/screenshots/surgedesk-mobile.png", fullPage: true });
});
